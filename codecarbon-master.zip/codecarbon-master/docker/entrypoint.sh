#!/bin/bash
# TODO : Run a Python code to use codecarbon package and call the API